document.addEventListener('DOMContentLoaded', () => {
    const images = document.querySelectorAll('.image-container img');
    const modal = document.getElementById('modal');
    const modalImg = document.getElementById('modal-image');
    const captionText = document.getElementById('modal-caption');
    const songText = document.getElementById('modal-song');
    const closeBtn = document.querySelector('.close');

    const songs = [
        "Here Comes the Sun - The Beatles",
        "Clouds - Zach Sobiech",
        "What a Wonderful World - Louis Armstrong",
        "Imagine - John Lennon",
        "Walking on Sunshine - Katrina and the Waves",
        "Blue Skies - Ella Fitzgerald",
        "Here Without You - 3 Doors Down",
        "Over the Rainbow - Judy Garland",
        "Firework - Katy Perry",
        "Sky Full of Stars - Coldplay",
        "Mr. Blue Sky - Electric Light Orchestra",
        "Sunshine - Matisyahu",
        "Pocketful of Sunshine - Natasha Bedingfield",
        "Good Day Sunshine - The Beatles",
        "Daydream Believer - The Monkees",
        "Skyfall - Adele",
        "Rocket Man - Elton John",
        "Drops of Jupiter - Train",
        "Fly Me to the Moon - Frank Sinatra",
        "Stairway to Heaven - Led Zeppelin",
        "Purple Haze - Jimi Hendrix",
        "Across the Universe - The Beatles",
        "Helios - Flume",
        "Sunflower - Post Malone",
        "Black Hole Sun - Soundgarden",
        "Venus - Shocking Blue",
        "New Moon Rising - Wolfmother",
        "Space Oddity - David Bowie",
        "Here Comes the Night - Them",
        "Paint It Black - The Rolling Stones",
        "Sunny Afternoon - The Kinks",
        "Eclipse - Pink Floyd",
        "Skyline To - Frank Ocean",
        "Sun King - The Beatles",
        "Sky High - Jigsaw",
        "Sunshine Superman - Donovan",
        "Walking on the Moon - The Police",
        "A Sky Full of Stars - Coldplay",
        "Sunshine of Your Love - Cream",
        "Blinded by the Light - Manfred Mann's Earth Band"
    ];

    images.forEach(img => {
        img.addEventListener('click', (e) => {
            const container = e.target.closest('.image-container');

            modal.style.display = 'block';
            modalImg.src = e.target.src;
            const randomSong = songs[Math.floor(Math.random() * songs.length)];
            songText.textContent = `Recommended Song: ${randomSong}`;
        });
    });

    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });
});
