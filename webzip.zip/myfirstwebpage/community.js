document.addEventListener('DOMContentLoaded', () => {
    const uploadForm = document.getElementById('uploadForm');
    const postsContainer = document.getElementById('postsContainer');

    uploadForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const imageInput = document.getElementById('image');
        const commentInput = document.getElementById('comment');

        // Create a new post element
        const post = document.createElement('div');
        post.className = 'post';

        // Handle image upload
        const reader = new FileReader();
        reader.onload = (event) => {
            const img = document.createElement('img');
            img.src = event.target.result;
            img.alt = 'User uploaded image';
            post.appendChild(img);

            // Add comment
            const comment = document.createElement('p');
            comment.textContent = commentInput.value;
            post.appendChild(comment);

            // Add the post to the container
            postsContainer.appendChild(post);
        };

        // Read the image file as a data URL
        reader.readAsDataURL(imageInput.files[0]);

        // Clear the form inputs
        imageInput.value = '';
        commentInput.value = '';
    });
});
